

























# Project 6 - Skip Lists - Report

#### Date: 2021-6-7



































## Chapter 1: Introduction

###### Background

**Skip list** is a data structure similar to **linked list**, designed for better search, insertion, deletion effciency. In fact, the expected time complexities of these three operations are all $O(\log n)$, which will be proved in later chapters.

###### Motivation and Simple Introduction

What is a skip list and why do we need skip lists? It's known that searching in a linked list will cost $O(n)$ time, and we hope to improve this. An idea is to add a layer of **extra pointers** within some nodes, which *skip* some nodes and point to a further position so that we can access a node more efficiently, like the *b* list below:

<img src=".\fig\introduction1.png" alt="introduction1" style="zoom: 67%;" />

<center><small>Figure 1: a linked list with an extra layer<sup>[1]</sup></small></center>

It's natural to add more layers, and by doing so we obtain a **skip list** (list *d*):

<img src=".\fig\introduction2.png" alt="introduction2" style="zoom: 67%;" />

<center><small>Figure 2: linked lists with extra layers<sup>[1]</sup></small></center>

For more details on how to search, insert and delete value within a skip list, let's go to the [**Algorithm Specification**](#Chapter-2:-Algorithm-Specification) part.

###### Our Tasks

1. *Introduce and implement* the skip list data structure, including **insertion, deletion and search** operations.
2. *Prove and show by testing* that the time complexity upper bounds of the above three operations are $O(\log n)$.
3. *Analyze with tables and graphs* the performance of skip lists.



## Chapter 2: Algorithm Specification

There are several ways to implement skip lists. One is to present each node with a **value** and **many pointers**, each pointing to certain node after it, as shown in the figure in the **Introduction** part. However, we are to implement it in another way, where each node consists of a **value**, a `next` pointer, and a `down` pointer. This can be illustrated by the following figure:

<img src=".\fig\AS.png" alt="AS" style="zoom: 50%;" />

<center><small>Figure 3: our implementation of skip lists</small></center>

### Data Structure

The data structure is as follow:

```C
typedef struct _skipNode{
    int value;
    struct _skipNode *next;
    struct _skipNode *down;
} skipNode, *skipList;
```

- `value` stores the data element, except that if the node is a dummy head of some layer, `value` stores the level of that layer.
- `next` is a pointer to the next node in the same layer, or `NULL` when there's no next node.
- `down` is a pointer to the node with the same value in the next lower layer, or `NULL` if it's already in the bottom layer.

The skip list will sort the element in ascending order, and each skip list **has a dummy head for each layer**.

### Creation

A few jobs are done to create and intialize an empty skip list:

1. Allocate spaces for the dummy head of the bottom level.
2. Set `value` of the head node as $0$, which means that the level number is counted from $0$, and `next` as `NULL`.
3. Return the pointer to the dummy head.

### Search

To decide if a given element, **say X**, is in the skip list, the program will:

1. Start from the head of the highest layer of the list.
2. While <font color = darkblue>**next_node.value < X**</font>, <font color = darkred>**jump next**</font>.
3. If <font color = darkblue>**next_node.value = X**</font>, <font color = dark>**return true**</font>.
4. If <font color = darkblue>**this is not the bottom layer**</font>, <font color = darkred>**jump down**</font> for more careful search, <font color = darkred>**and go to step 2**</font>. Else it means that the given value doesn't exists, so <font color = dark>**return false**.</font>

### Deletion

When a value **X** is to be removed from the skip list, the program will:

1. Start from the head of the highest layer the list.
2. While <font color = darkblue>**next_node.value < X**</font>, <font color = darkred>**jump next**</font>.
3. If <font color = darkblue>**next_node.value = X**</font>, <font color = dark>**delete that node**</font>, and if after deletion, <font color = darkblue>**the current layer has no elements (except the dummy head) and is not the bottom layer**</font>, <font color = dark>**delete the current layer**</font>.
4. No matter whether there's a deletion or not, <font color = darkred>**jump down**</font> for more careful search <font color = darkred>**and go to step 2**</font>, unless <font color = darkblue>**this is the bottom layer**</font>.
5. <font color = dark>**Return 0**</font> if there's ever any deletion, else <font color = dark>**return -1**</font>. 

### *get_random_level* function

This function returns a integer representing the highest level that the inserted element will be present. The intial level is set as $0$, and then we run a trial procedure which **will succeed with a pre-set probability $p$**, which we call **upgrade probability**. If <font color = darkblue>**the trial succeeds**</font>, the level will increase $1$ and we rerun the procedure. If <font color = darkblue>**it fails**</font>, the level will not increase and we'll return the level. However, our level 

### Insertion

If a value **X** is required to be inserted into the skiplist, the program will:

1. Call *find()* to decide whether X already exists, if so <font color = dark>**return -1**</font>.
2. Call *get_random_level()* to decide how many layers will the inserted value exist in (starting from 0). If <font color = darkblue>**inserted level > max current level**</font>,  <font color = dark>**create all needed new layers**</font>.
3. Start from the highest layer.
4. While <font color = darkblue>**next_node.value < X**</font>, <font color = darkred>**jump next**</font>.
5. If <font color = darkblue>**current level <= inserted level**</font>, which means the value should appear in this layer, <font color = dark>**insert the value**</font> between the current node and the next node.
6. <font color = darkred>**Jump down and go to step 4**</font>, unless <font color = darkblue>**this is the bottom layer**</font>.
7. <font color = dark>**Return 0**</font> for the successful insertion.



## Chapter 3: Testing Result

- #### Test standard

  - Insert : Insert **a random element** into a **SkipList** with N data
  - Search :  Search **a random element** into a **SkipList** with N data
  - Delete : Delete **a random element** into a **SkipList** with N data
  - notice : Take the average value of **n independent repeated tests** to ensure the reliability of the results

- #### Run Time Table

The table below shows the time cost of insertion, search and deletion operation **when different $p$, the upgrade probability, is chosen**. The reason why we choose the 'magic number' $\cfrac1e$ will be illustrated in our analysis. Before this it's worth noticing that among these conditions, the skip list performs best when $p=\cfrac1e$.

*unit for Insert, Search and Delete: μs*

|         |        | p = 0.25 |        |        | p=1/e  |        |        |
| :------ | ------ | -------- | ------ | ------ | ------ | ------ | ------ |
| **No.** | Scale  | Insert   | Search | Delete | Insert | Search | Delete |
| 1       | 10     | 0.37     | 0.25   | 0.37   | 0.34   | 0.23   | 0.43   |
| 2       | 50     | 0.52     | 0.16   | 0.20   | 0.40   | 0.14   | 0.23   |
| 3       | 100    | 0.40     | 0.17   | 0.22   | 0.38   | 0.16   | 0.24   |
| 4       | 500    | 0.41     | 0.18   | 0.23   | 0.39   | 0.18   | 0.25   |
| 5       | 1000   | 0.38     | 0.19   | 0.22   | 0.41   | 0.19   | 0.25   |
| 6       | 4000   | 0.43     | 0.21   | 0.27   | 0.43   | 0.21   | 0.28   |
| 7       | 10000  | 0.46     | 0.23   | 0.30   | 0.51   | 0.25   | 0.34   |
| 8       | 20000  | 0.50     | 0.29   | 0.37   | 0.54   | 0.30   | 0.40   |
| 9       | 50000  | 0.65     | 0.55   | 0.46   | 0.63   | 0.57   | 0.61   |
| 10      | 80000  | 0.74     | 0.98   | 0.71   | 0.68   | 1.02   | 0.73   |
| 11      | 100000 | 0.85     | 1.23   | 1.00   | 0.80   | 0.98   | 0.95   |
| 12      | 120000 | 0.84     | 1.25   | 1.12   | 0.74   | 0.92   | 0.96   |

|         |        | p = 0.5 |        |        | p=0.7  |        |        |
| :------ | ------ | ------- | ------ | ------ | ------ | ------ | ------ |
| **No.** | Scale  | Insert  | Search | Delete | Insert | Search | Delete |
| 1       | 10     | 0.67    | 0.24   | 0.41   | 0.7    | 0.26   | 0.51   |
| 2       | 50     | 0.60    | 0.19   | 0.23   | 0.53   | 0.19   | 0.36   |
| 3       | 100    | 0.61    | 0.17   | 0.25   | 0.52   | 0.19   | 0.31   |
| 4       | 500    | 0.50    | 0.18   | 0.26   | 0.55   | 0.18   | 0.30   |
| 5       | 1000   | 0.48    | 0.19   | 0.27   | 0.55   | 0.20   | 0.33   |
| 6       | 4000   | 0.55    | 0.22   | 0.37   | 0.60   | 0.25   | 0.37   |
| 7       | 10000  | 0.57    | 0.27   | 0.37   | 0.65   | 0.31   | 0.45   |
| 8       | 20000  | 0.62    | 0.32   | 0.45   | 0.71   | 0.34   | 0.51   |
| 9       | 50000  | 1.51    | 0.48   | 0.58   | 1.06   | 0.94   | 0.65   |
| 10      | 80000  | 1.71    | 0.77   | 0.74   | 1.94   | 1.08   | 1.36   |
| 11      | 100000 | 1.66    | 0.93   | 0.84   | 1.99   | 1.60   | 1.51   |
| 12      | 120000 | 1.76    | 1.16   | 1.00   | 1.86   | 1.77   | 1.43   |

*Test case inputs  can be found in the 'sample' folder you download, with `size=[i].txt` the input of the test case with input size i.*



- #### N/log<sub>2</sub> N-Time Figure (400 randomly generated data files, ranging from 0 to 100000)

The following figures show the relation between the time needed for a certain operation and the input size $N$, and also the difference among three different data structure: **normal linked-list**, **skip list** and **B+ tree**.

(The reason why we choose B+ tree is that this data structure deploys exactly the same idea of **multi-layer indexes** as skip list. B+ tree is implemented with a pre-set *rank* while the skip list adds layer through a random procedure.)									

<img src=".\fig\insert.png" alt="image-20210607175047779" style="zoom:50%;" />

<img src=".\fig\search.png" alt="image-20210607175156727" style="zoom:50%;" />

<img src=".\fig\delete.png" alt="image-20210607175310056" style="zoom:55%;" />

<center><small>Figure 4: N/log<sub>2</sub> N-Time Figures</small></center>

It can be seen from the figure that the skip list has a fantasic performance compared to the traditional linked list. The time cost of skip list is nearly as small as B+ tree, but skip list is far more easier to implement. And the logN-time figure looks like a line, which implies that its time complexity is $O(\log n)$.



- #### p-N-level Figure && p-N-Nodes Figure

The figure below shows the relation between the number of layers (or nodes) of the skip list and the input size $N$ with different $p$. It's easy to find that the number of nodes are proportional to the input size while the growth of number of layers is somewhat seemingly logarithmic. What's more, as $p$ increases, the slope of the line increases as well. We'll discuss these findings later in this report.

<img src=".\fig\p-N-Nodes-level.png" alt="image-20210607101010433" style="zoom: 50%;" />

<center><small>Figure 5: p-N-level Figure (left) and p-N-Nodes Figure (right)</small></center>



## Chapter 4: Analysis

The time required to excute the *`Search`*, *`Delete`*, and *`Insert`* operation is dominated by the time required to search for the element. For the *`Insert`* and *`Delete`* operations, there is an additional cost proporational to the level of the node being inserted or deleted. The time required to find an element is proportional to the length of the search path, which is determined by the pattern in which elements with different levels appears as we traverse the list.

### Time Complexity

#### Search Cost

###### Average (Expected) Case

- **Analysis 1: A Rough Proof**

One of the ways to analyze the time complexity of *`Search`* is that since the proccess of searching is from the highest layer down to the initialized linked list, so we can safely draw the conclusion that

$$
T(Search)=O(\sum_{k=1}^{h}{S(k)})
$$
where $S(k)$ represents the number of elements traversed on the i-th level during the search.

First let's calculate how many layers will there be probabilistically for an input size $n$. Define 
$$
X^{(k)}_i=\cases{1,& \text{the i-th element appears in the k-th layer}\\0,&otherwise}
$$
and the number of elements in the k-th layer
$$
N(k)=\sum_{i=1}^n{X^{(k)}_i}
$$
Then we can find $P(X^{(k)}_i=1)=p^k$, $P(X^{(k)}_i=0)=1-p^k$. Then $N(k)$ is subject to a **binomial distribution** $B(n, p^k)$, hence drawn from a foregone conclusion
$$
E(N(k)) = n * p^k
$$
In expectiation, it forms a k-th layer when $E(N(k))\geq 1$, and further a level of height $h$ is the expected maximum level when
$$
E(N(h))\geq 1\;\&\;E(N(h+1))<1
$$
which indicates $\log_p{\frac1n}-1<h\leq\log_p{\frac1n}$.

**Therefore, probabilistically, we get $h = O(\log_p\frac1n)=O(\log_\frac1pn)$**, as the total number of layers in the skip list. This can be verified by the "level - N" figure in the previous chapter.

Then we will show how many nodes will be traversed at any given level. Every node, already appearing in the i-th level in the process of running the *random_get_level function*, will have a chance of $p$ to go further into the upper level. We regard the fact as that in expectation, from every $\cfrac1p$ nodes in the k-th level, one will be chosen to go into the (k+1)-th level. So we **traverse at most $\cfrac1p$ nodes in every level in expectation**, since if we traverse more than $\cfrac1p$ nodes in some level, we should have got to this place through the upper level in just two steps! (But well, speaking probabilistically.)

Concluding the result above, we can get that the time complexity for *`Search`* is
$$
O(\cfrac1p \times h)=O(\cfrac1p\times\log_\frac1p n)=O(\log_{p^{-p}}n)=O(\log n)
$$

- **Analysis 2: A More Detailed Proof Inspired by the Primary Paper<sup>[1]</sup>**

Another way is that we can analyze the search path backwards, that is, to travel up and to the left from the data to be found in the bottom layer. Although the number of occupied layers of any node in the skip list is known and fixed when the *`Search`* is performed, we act as if it is being determined only when observed while we're backtracking the search path.

At any particular point in the backward path, we will be at a certain node in the skip list, say **level $k$** and **data $x$**. And we have two choice here: **climb up** or **climb left**. As stated above, the number of occupied layers of the node is not determined **until now**. We **climb up** (that is to say, we climb down to this node when performing `search`) iff there exists a node in level $k+1$ and with data $x$. The probability of this case is exactly $p$, the upgrade probability. Otherwise we will have to **climb left**, with a probability of $1-p$. 

Define $C(k)$ as the cost when we still need to climb up $k$ levels. Then we shall have $C(0)=0$ and
$$
C(k)=(1-p)(1+C(k))+p(1+C(k-1))=1+(1-p)C(k)+pC(k-1)
$$
from which $C(k) = 1/p \ +C(k-1)$, **and hence $C(k) = k/p$**.

<img src="./fig/Analysis.png" alt="Analysis" style="zoom:50%;" />

<center><small>Figure 6: possible situations in backwards traversal of the search path<sup>[1]</sup></small></center>

Note that we hold the assumption that the list is infinite, that is, we are **able to climb left for infinite times**. However, when we have already reached the head of any layer of the list, we simply climb up it, without performing any leftward movements. It means that under this circumstances, when we climb up one layer, the cost increases by exactly $1$ instead of $\cfrac 1p$. Due to the fact that $\cfrac1p>1$,  $\cfrac kp$ is actually an upper bound of $C(k)$, which doesn't matter since we're using the big-O notation.

The probability that  $h>k$ is equal to $1-(1-p^{k+1})^n$, this is no greater than $np^{k+1}$ according to the **Bernouli Inequality**. From this we can calculate **the expected maximum level is at most $\log_{\frac1p}{n}-1+\cfrac1{1-p}$<sup>[1]</sup> **(as a matter of fact, here we prove that it's at most $\log_{\frac1p}{n}-1+\cfrac1{(1-p)^2}$ [see [Appendix A](#Appendix A: A Proof))], slightly bigger than the figure in the paper, but this won't affect the final result). So the cost will be no more than
$$
\cfrac{\log_{\frac1p}{n}-1+1/(1-p)}p=\cfrac{\log_{\frac1p}{n}}p+\cfrac1{1-p}=O(\log_{p^{-p}}n)+O(1)
$$
Eventually we can draw the conclusion that the time complexity for *`Search`* is $O(\log_{p^{-p}}n)$, or $O(\log n)$.

###### Worst Case

We obtain a worst case when the skip list is reduced to a linked list, which means that every node occupies just the bottom layer! At this point, the time needed for searching an element is the same as that in a linked list, that is, $O(n)$.

#### Insertion Cost

###### Average (Expected) Case

The *`Insert`* Algorithm is built on the *`Search`* Algorithm. After finding the position needed to insert a node costing time $O(\log n)$, we insert the nodes in the neccessary layer. The time complexity of inserting one node in a linked list is $O(1)$, and the expected number of layers needing insertion is (here $P(h=k)=p^{k-1}(1-p)$ is the probability that the random trail fails after $k$ successful ones)
$$
E(h)=\sum_{k=1}^\infty kP(h=k)=\sum_{k=1}^\infty kp^{k-1}(1-p)=\cfrac 1{1-p}
$$
which is $O(1)$, so we can make a conclusion that the expected time complexity of *`Insert`* is $O(\log n)$.

###### Worst Case

While an element can be inserted into infinity layers in the worst case, if we restrict t the number of insertions to be at most $m$ by setting maximum level allowed as $m$, a certain constant. Plus the worst case search time complexity $O(n)$, we'll have the worst case time complexity to be $O(n)$.

#### Deletion Cost

###### Average (Expected) Case

The *`Delete`* Algorithm is also built on the *`Search`* Algorithm. First we judge if the node exists within $O(\log n)$ time, and  then find that node to be deleted costing $O(\log n)$. Then as every level is a sorted linked list, deleting a node in one level takes $O(1)$ time, and there are at most $h=O(\log n)$ levels expectedly, so delete operation takes $O(1\times\log n)$ times at most. Finally the total time complexity for deletion $O(\log\ n)$.

###### Worst Case

The times needed for deletion is still $O(\log n)$, but with the search time reduced to $O(n)$ in the worst case, the same is true with the delete operation.

### Space Complexity

###### Average (Expected) Case

As stated above, the expectational number of nodes for the k-th level is $np^k$. Adding up this for $k = 0$ to infinity, the total number of nodes would be
$$
O(n\times(1+p+p^2+\cdots+p^k+\cdots)) = O(n\times\cfrac1{1-p})=O(n)
$$
As a result, the space complexity for the skip list should be $O(n)$, probabilistically.

###### Worst Case

In worst case, every element can occupy an infinite number of layers. However, when setting a restrictional maximum level $m$, for every element we can create $m$ nodes at mose. Therefore, the space complexity in the worst case is $O(mn)=O(n)$, regarding the maximum level $m$.

### Further Corollary

###### Time complexity regarding $p$

Let's focus on the average time complexity of the search operation, that is, $O(\log n)$, or more specifically, $O(\log_{p^{-p}}n)$. This complexity varies as the probability $p$ changes. When does it reach its minimum, assuming $n$ fixed?

Function
$$
f(x) = \log_xn=\cfrac1{\log_nx}
$$
decreases as $x$ increases when $n>1$, so we shall find the maximum of the function 
$$
f(p)=p^{-p}=e^{-p\ln p}
$$
which is equivalent to finding the minimum of the function
$$
g(p)=p\ln p
$$
Clearly $g^\prime(p) = 1+\ln p$ has zero point $p=\cfrac1e$, and $g^\prime(p) < 0$ if $p<\cfrac1e$, $g^\prime(p) > 0$ if $p>\cfrac1e$. Therefore, $p=\cfrac1e$ is the minimum we are finding.

That is to say, the average time taken to search a given element in the skip list reaches it minimum when $p=\cfrac1e$ assuming $n$ fixed, which can be shown by our test result.

###### Space complexity regarding $p$

Since the expected space complexity is $O(\cfrac n{1-p})$ from our calculation above, it can be drawn that larger the upgrade probablility $p$ is, the more space will be used by the skip list. We can verify this result by the "p-N-level" figure.



## Appendix A: A Proof

Show that
$$
\text{expected maximum level} \leq \log_{\frac1p}{n}-1+\cfrac1{(1-p)^2}
$$

* Proof:

  We've already known that $E(N(k)) = n * p^k$. Pick $\theta = \log_{\frac1p}{n}-1$, we get the expected number of nodes at level $\theta$ is $ \cfrac1p$. Since the trial procedure is **non-aftereffect**, we can calculate the expected maximum level **counted from level $\theta$**, add it to $\theta$, and the get the maximum level of the whole linked-list.

  We've already illustrated that
  $$
  P(h>k)=1-(1-p^{k+1})^n\leq np^{k+1}
  $$
  where $h$ is the maximum level and $n$ the number of elements at the bottom level. The nodes at and above level $\theta$  can be viewed as another skip list with bottom level $\theta$, hence $n=\cfrac 1p$. Therefore, the expected maximum level of this skip list is
  $$
  E(\Theta) = 0+\sum_{k=1}^\infty kP(h=k)\leq\sum_{k=1}^\infty kP(h>k-1)\leq\sum_{k=1}^\infty k\times np^k=n\times\cfrac p{(1-p)^2}=\cfrac1{(1-p)^2}
  $$
  So the expected maximum level is no more than $\theta+\Theta=\log_{\frac1p}{n}-1+\cfrac1{(1-p)^2}$.



## Appendix B: Source Code

###### skip_lists.cpp

```C
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define upgrade_prob 0.5 //晋升一层的概率 
#define MAX_LEVEL 16     //最高层数限制 

//跳表结点数据结构，数据顺序为从小到大 
typedef struct _skipNode{
    int value;  			/* 结点值 */ /* 当结点为所在层的哨兵时，该值表示所在层数 */ 
    struct _skipNode *next; /* 同层下一结点 */ 
    struct _skipNode *down; /* 下一层结点 */ 
} skipNode, *skipList;

/*
    作用：新建一个空跳表，带dummy head头哨兵 
    参数：无
    返回值：skipList，新建跳表的头哨兵指针 
*/ 
skipList alloc_skipList(){
    skipList head = (skipList)malloc(sizeof(skipNode));   /* 头哨兵 */
    head->value = 0;                                      /* 层数从0始计 */
    head->next = head->down = NULL;
    return head;
}

/*
    作用：在给定跳表中寻找值 
    参数：head-跳表头哨兵指针；x-要寻找的值 
    返回值：int，1表示该值存在于跳表中，2表示不存在
*/ 
int find(skipList head, int x){
    skipNode *cur = head;    /* 记录当前所在的结点 */
    /* 从链表头开始遍历 */ 
    while(cur){
        /* 在每层中跳至第一个不小于x的结点前面 */
        while(cur->next && cur->next->value < x) cur = cur->next;
        /* 若后面的结点值正好为x，则已找到 */
        if(cur->next && cur->next->value == x) return 1;
        /* 否则进入下一层，更小步地跳 */
        cur = cur->down;
    }
    /* 最后没有找到，则元素不存在 */
    return 0;
}

/*
    作用：在给定跳表中移除某个元素 
    参数：L-跳表头哨兵指针的指针；x-要移除的元素 
    返回值：int，0表示移除成功，1表示移除失败（含有该值的结点不存在） 
*/ 
int remove(skipList *L, int x){
    skipNode *head = *L;     /* 链表头 */ 
    skipNode *cur = head;    /* 记录当前所在的结点 */
    int ret = -1;            /* 函数返回值，记录是否存在要删的结点 */ 
    /* 从链表头开始遍历 */ 
    while(cur){
        int flag = 0;        /* 用于记录当前层是否已经不存在数据结点 */ 
        /* 在每层中跳至第一个不小于x的结点前面 */
        while(cur->next && cur->next->value < x) cur = cur->next;
        /* 若后面的结点值正好为x */
        if(ret == 0 || (cur->next && cur->next->value == x)){
            /* 更新返回值 */
            ret = 0;
            /* 执行删除 */
            skipNode *target = cur->next;                               
            cur->next = target->next;
            free(target);
            /* 并且判断该层是否已经无结点*/
            if(cur == head && cur->next == NULL) flag = 1;
        }
        cur = cur->down;/* 进入下一层，更小步地跳 */
        
        /* 若该层已无结点且不为最底层 */
        if(flag && cur) {
            /* 删除该层 */
            free(head);
            head = cur;
        }
    }
    /* 更新链表头 */
    *L = head;
    
    return ret;
}

/*
    作用：在插入新结点时，为该结点获取一个随机层数 
    参数：无
    返回值：int，随机获得的层数 
*/ 
int get_random_level(){
    int level = 0;
    rand();
    /* 每次以概率upgrade_prob跃升 */
    while ((double)(rand()) / RAND_MAX < upgrade_prob && level < MAX_LEVEL) level++;
    return level;
}

/*
    作用：在给定跳表中插入某个元素 
    参数：L-跳表头哨兵指针的指针；x-要插入元素 
    返回值：int，0表示插入成功，1表示插入失败（该元素已存在） 
*/ 
int insert(skipList *L, int x){
    skipNode *head = *L;         /* 链表头 */ 
    if(find(head, x)) return -1; /* 若要插入的值已存在，直接返回-1 */ 
    
    //决定插入层数 
    int total_level = head->value;          /* 链表当前层数 */ 
    int insert_level = get_random_level();  /* 插入结点要跨越的层数 */
    /* 若插入层数大于当前层数 */
    if(insert_level > total_level){
        /* 限制为只多加一层 */
        insert_level = total_level + 1;
        
        /* 为新加的一层配备头哨兵 */
        skipNode *newHead = (skipNode*)malloc(sizeof(skipNode));
        newHead->value = total_level + 1;                               
        newHead->down = head;
        newHead->next = NULL;
        /* 更新链表头 */
        *L = newHead;
        
        total_level++;
    }
    
    //执行插入 
    head = *L;                              /* 新的链表头 */
    int cur_level = total_level;            /* 遍历过程中记录当前所在层数 */ 
    skipNode *cur = head;                   /* 记录当前所在的结点 */
    skipNode *last_level_new = NULL;        /* 记录上一层中新加入的结点 */
    /* 从头结点开始遍历 */
    while(cur){
        /* 在每层中跳至第一个不小于x的结点前面 */
        while(cur->next && cur->next->value < x) cur = cur->next;
        /* 如果位于要插入结点的层 */
        if(cur_level <= insert_level){
            /* 插入新结点 */
            skipNode *newNode = (skipNode*)malloc(sizeof(skipNode));
            newNode->value = x;
            newNode->next = cur->next;
            newNode->down = NULL;
            cur->next = newNode;
            
            /* 将上层插入结点的下层结点更新为本层插入的结点 */
            if(last_level_new) last_level_new->down = newNode;
            /* 并更新上层插入结点 */
            last_level_new = newNode;
        }
        
        /* 然后进入下一层，继续执行插入 */
        cur = cur->down;
        cur_level--;
    } 
    return 0; /* 插入成功 */
}

/*
    作用：打印给定跳表 
    参数：L-跳表头哨兵指针
    返回值：无 
*/ 
void print(skipList head){
    //处理空表 
    if(head->next == NULL) {
        printf("Empty skip list!\n");
        return;
    }
    
    /* 打印层数 */
    printf("total level : %d\n", head->value);
    /* 遍历每一层，打印所有结点 */
    for(skipNode *curHead = head; curHead; curHead = curHead->down){
        for(skipNode *cur = curHead->next; cur; cur = cur->next){
            printf("%d->", cur->value);
        }
        printf("\n");
    }
}

/* simple test bench */

int main(){
    srand(time(NULL));
    skipList L = alloc_skipList();
    int insert_list[] = {3,6,7,9,1,4,8,0,2,4,5,16,23,25,7,19,19,34,3,22};
    int find_list[] = {1,3,5,11,13,16,18,19,20,24,25,30,40,34};
    
    /*  插入测试  */
    for(auto i : insert_list) {
        if (insert(&L, i) >= 0) print(L);
        else printf("%d duplicate\n", i);
        printf("-----------------------\n");
    }
    
    /*  查找测试  */
    for(auto i : find_list) {
        if (find(L, i)) printf("%d exists\n", i);
        else printf("%d not exist\n", i);
    }
    
    /*  删除测试  */
    for(auto i : insert_list) {
        if (remove(&L, i) >= 0) print(L);
        else printf("%d not exist\n", i);
        printf("-----------------------\n");
    }
    return 0;
}
```



## References

[1] Pugh W . Skip lists: a probabilistic alternative to balanced trees[C]// Workshop on Algorithms & Data Structures. 1990.



## Declaration

*We hereby declare that all the work done in this project titled "Project 6 - **Skip Lists** " is of our team's independent effort.*
1.The folder "test" contains the test cases, you can use them to judge the functions of the project.
2.Voting Tree.cpp is the main source code of the project, just click it twice and run it.
Use devc++ or other compiler to build the .exe file and input data as required. 
